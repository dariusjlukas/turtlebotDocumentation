# turtlebotDocumentation
Documentation for setting up and using a turtlebot3 with a jetson nano and Mynt Eye D.

To run locally, double click the index.html file and it should open in a web browser. It is server from a pi in the lab.