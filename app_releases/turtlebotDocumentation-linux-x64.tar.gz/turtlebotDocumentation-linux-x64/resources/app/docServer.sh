#!/bin/bash

git pull &
http-server &
